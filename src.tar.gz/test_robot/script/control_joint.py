#!/usr/bin/env python

import rospy
from gazebo_msgs.srv import SetModelConfiguration
from gazebo_msgs.srv import SetModelConfigurationRequest

rospy.init_node('robot_control')

reset_joints =  rospy.ServiceProxy('/gazebo/set_model_configuration', SetModelConfiguration)

reset_req = SetModelConfigurationRequest()
reset_req.model_name = 'test_robot'
reset_req.urdf_param_name = 'robot_description'
# reset_req.joint_names = ['botton_joint_1_1','botton_joint_1_2','botton_joint_1_3','botton_joint_1_4','botton_joint_1_5'] #list
reset_req.joint_names = ['botton_joint_1_1','botton_joint_1_2','botton_joint_1_3']
del_theta = 0.05
lower_theta = -0.5
upper_theta = 0.7

theta = lower_theta

rate = rospy.Rate(10) # 10hz


while not rospy.is_shutdown():
    if theta >upper_theta or theta < lower_theta:
        del_theta = -del_theta
    theta = theta + del_theta
    #reset_req.joint_positions = [-theta,2*theta,-theta,theta,-2*theta] #list
    reset_req.joint_positions = [-theta,2*theta,-theta] #list
    res = reset_joints(reset_req)
    rate.sleep()

